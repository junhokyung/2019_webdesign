<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

if (G5_IS_MOBILE) {
    include_once(G5_THEME_MOBILE_PATH.'/head.php');
    return;
}

include_once(G5_THEME_PATH.'/head.sub.php');
include_once(G5_LIB_PATH.'/latest.lib.php');
include_once(G5_LIB_PATH.'/outlogin.lib.php');
include_once(G5_LIB_PATH.'/poll.lib.php');
include_once(G5_LIB_PATH.'/visit.lib.php');
include_once(G5_LIB_PATH.'/connect.lib.php');
include_once(G5_LIB_PATH.'/popular.lib.php');
?>

<!-- 상단 시작 { -->
<div id="hd">
    <h1 id="hd_h1"><?php echo $g5['title'] ?></h1>

    <div id="skip_to_container"><a href="#container">본문 바로가기</a></div>

    <?php
    if(defined('_INDEX_')) { // index에서만 실행
        include G5_BBS_PATH.'/newwin.inc.php'; // 팝업레이어
    }
    ?>

    <div id="hd_wrapper">

        <div id="logo">
            <a href="<?php echo G5_URL ?>"><img src="<? echo G5_THEME_IMG_URL ?>/logo.PNG" alt="<?php echo $config['cf_title']; ?>"></a>
        </div>

    <nav id="gnb">
        
        <div class="gnb_wrap">
            <ul id="gnb_1dul">
               
                <?php
                $sql = " select *
                            from {$g5['menu_table']}
                            where me_use = '1'
                              and length(me_code) = '2'
                            order by me_order, me_id ";
                $result = sql_query($sql, false);
                $gnb_zindex = 999; // gnb_1dli z-index 값 설정용
                $menu_datas = array();

                for ($i=0; $row=sql_fetch_array($result); $i++) {
                    $menu_datas[$i] = $row;

                    $sql2 = " select *
                                from {$g5['menu_table']}
                                where me_use = '1'
                                  and length(me_code) = '4'
                                  and substring(me_code, 1, 2) = '{$row['me_code']}'
                                order by me_order, me_id ";
                    $result2 = sql_query($sql2);
                    for ($k=0; $row2=sql_fetch_array($result2); $k++) {
                        $menu_datas[$i]['sub'][$k] = $row2;
                    }

                }

                $i = 0;
                foreach( $menu_datas as $row ){
                    if( empty($row) ) continue; 
                ?>
                <li class="gnb_1dli" style="z-index:<?php echo $gnb_zindex--; ?>">
                    <a href="<?php echo $row['me_link']; ?>" target="_<?php echo $row['me_target']; ?>" class="gnb_1da"><?php echo $row['me_name'] ?></a>
                   
                </li>
                <?php
                $i++;
                }   //end foreach $row

                if ($i == 0) {  ?>
                    <li class="gnb_empty">메뉴 준비 중입니다.<?php if ($is_admin) { ?> <a href="<?php echo G5_ADMIN_URL; ?>/menu_list.php">관리자모드 &gt; 환경설정 &gt; 메뉴설정</a>에서 설정하실 수 있습니다.<?php } ?></li>
                <?php } ?>
            </ul>
            
        </div>
    </nav>
</div>

    
</div>
<!-- } 상단 끝 -->


<hr>
<? if(defined("_INDEX_")){ ?>
    <!-- <div style="height: 400px;background: #f00"></div> -->

<div class="visual1">
    <img src="<? echo G5_THEME_IMG_URL ?>/visual1.jpg" alt="">
    <div class="visual_txt">
        <h1>어쩌면 삶은<br>인생이라는 종이 위에<br>써 내려가는<br>펜의 기록 같습니다.</h1>
        <p>그중에서도 지우고 싶지 않은 기록이 있습니다.<br>모나미는 언제나 당신의 행복한 기록과 함께 합니다.</p>
    </div>
</div>
<script>
    $(function(){
        $(".content1 > div").mouseover(function(){
            $(this).find(".ondiv").stop().fadeIn();
        }).mouseout(function(){
            $(this).find(".ondiv").fadeOut();
        });
        $(".content2 > div").mouseover(function(){
            $(this).find(".ondiv").stop().fadeIn();
        }).mouseout(function(){
            $(this).find(".ondiv").fadeOut();
        });
    });
</script>

<div class="content1 clearfix">
    <ul class="title">
        <h1>NEW<br>ARRIVALS</h1>
        <p>가장 먼저 만나는 설레는 기다림</p>
    </ul>

    <div class="cont1_first">
        <img src="<? echo G5_THEME_IMG_URL ?>/main01.jpg" alt="" class="first">
        <div class="ondiv">
            <span>FOUNTAIN PEN<br><p>153 네오 만년필</p></span>
            <div class="plus"><p>+</p></div>
        </div>
    </div>
    <div class="cont1_second">
        <img src="<? echo G5_THEME_IMG_URL ?>/main02.jpg" alt="">
        <div class="ondiv">
            <span>BALL POINT PEN<br><p>153 야미</p></span>
            <div class="plus"><p>+</p></div>
        </div>
    </div>
</div>
<div class="content2 clearfix">
    <div class="cont2_first">
        <img src="<? echo G5_THEME_IMG_URL ?>/main03.jpg" alt="">
        <div class="ondiv">
            <span>WATER BASED PEN<br><p>컬러 트윈 브러쉬</p></span>
            <div class="plus"><p>+</p></div>
        </div>
    </div>
    <div class="cont2_second">
        <img src="<? echo G5_THEME_IMG_URL ?>/main04.jpg" alt="">
        <div class="ondiv">
            <span>HOME & DIY MARKER<br><p>세라믹 마카 480/482</p></span>
            <div class="plus"><p>+</p></div>
        </div>
    </div>
    <div class="cont2_last">
        <img src="<? echo G5_THEME_IMG_URL ?>/main05.jpg" alt="">
        <div class="ondiv">
            <span>INK DIY<br><p>잉크 DIY</p></span>
            <div class="plus"><p>+</p></div>
        </div>
    </div>
</div>
<script>
    $(function(){
    var current = 0;
    var i;
        function slider(){
            i = (current + 1) % 2;
            $(".bn_img>ul").eq(current).css({left:0}).stop().animate({left:-2002},10000);
            $(".bn_img>ul").eq(i).css({left:2002}).stop().animate({left:0},10000);
            current = i;
        }
        setInterval(slider,10000)
        slider();

        $(".bn_btn>ul>li").click(function(){
            $(".bn_btn>ul>li").removeClass();
            $(this).addClass("active");
        });
    });        
</script>
<div class="banner">
    <div class="bn_txt">
        <h1>BEST PRODUCT</h1>
        <p>언제나 어디서나 생활 속에 함께하는 모나미</p>
    </div>
    <div class="bn_btn clearfix">
        <ul>
            <li class="active"><a href="javascript:void(0)">펜</a></li>
            <li><a href="javascript:void(0)">마카</a></li>
            <li><a href="javascript:void(0)">형광펜</a></li>
            <li><a href="javascript:void(0)">회화구류</a></li>
        </ul>
    </div>
    <div class="bn_img">
        <ul>
            <li>
                <a href="javascript:void(0)">
                    <img src="<? echo G5_THEME_IMG_URL ?>/pen01.jpg" alt="">
                    <p>FX153<br><span>FX153</span></p>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
                    <img src="<? echo G5_THEME_IMG_URL ?>/pen02.jpg" alt="">
                    <p>프리미엄펜<br><span>153네이처</span></p>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
                    <img src="<? echo G5_THEME_IMG_URL ?>/pen03.jpg" alt="">
                    <p>유성볼펜<br><span>153 야미</span></p>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
                    <img src="<? echo G5_THEME_IMG_URL ?>/pen04.jpg" alt=""><p>프리미엄펜<br><span>153 블라썸</span></p>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
                    <img src="<? echo G5_THEME_IMG_URL ?>/pen05.jpg" alt="">
                    <p>프리미엄펜<br><span>153 네오 만년필</span></p>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
                    <img src="<? echo G5_THEME_IMG_URL ?>/pen06.jpg" alt=""><p>프리미엄<br><span>153 네오 (밀키)</span></p>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
                    <img src="<? echo G5_THEME_IMG_URL ?>/pen07.jpg" alt="">
                    <p>프리미엄<br><span>153 블랙 & 화이트</span></p>
                </a>
            </li>
        </ul>
        <ul>
            <li>
                <a href="javascript:void(0)">
                    <img src="<? echo G5_THEME_IMG_URL ?>/pen01.jpg" alt="">
                    <p>FX153<br><span>FX153</span></p>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
                    <img src="<? echo G5_THEME_IMG_URL ?>/pen02.jpg" alt="">
                    <p>프리미엄펜<br><span>153네이처</span></p>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
                    <img src="<? echo G5_THEME_IMG_URL ?>/pen03.jpg" alt="">
                    <p>유성볼펜<br><span>153 야미</span></p>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
                    <img src="<? echo G5_THEME_IMG_URL ?>/pen04.jpg" alt="">
                    <p>프리미엄펜<br><span>153 블라썸</span></p>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
                    <img src="<? echo G5_THEME_IMG_URL ?>/pen05.jpg" alt="">
                    <p>프리미엄펜<br><span>153 네오 만년필</span></p>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
                    <img src="<? echo G5_THEME_IMG_URL ?>/pen06.jpg" alt="">
                    <p>프리미엄<br><span>153 네오 (밀키)</span></p>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
                    <img src="<? echo G5_THEME_IMG_URL ?>/pen07.jpg" alt="">
                    <p>프리미엄<br><span>153 블랙 & 화이트</span></p>
                </a>
            </li>
        </ul>
    </div>
</div>

<div id="banner2">
    <div class="bn_wrap clearfix">
        <div class="news">
            <li class="news_lf">
                <a href="javascript:void(0)">
                    <h1>MONAMI NEWS</h1>
                    <img src="<? echo G5_THEME_IMG_URL ?>/sec_img.jpg" alt="">
                </a>
            </li>
            <li class="news_rg">
                <a href="javascript:void(0)">
                    <h1>모나미, 'FX 153 광복절 기념 패키지' 한정판</h1>
                    <p>모나미, 'FX 153 광복절 기념 패키지' 한정판으로 선보여-모나미 저점도 잉크 FX 153 볼펜, 8·15 컨셉 한정판 패키지</p>
                    <span>2019-08-07</span>
                </a>
            </li>
        </div>
        <div class="inquiry">
            <img src="<? echo G5_THEME_IMG_URL ?>/sec_img2.png" alt="">
            <h1>INQUIRY</h1>
            <p>소중한 의견에 귀 기울이겠습니다.<br>궁금한 사항은 문의하세요.</p>
            <li class="bn2_btn">
                <span>INQUIRY NOW</span>
            </li>
        </div>
        <div class="family">
            <img src="<? echo G5_THEME_IMG_URL ?>/sec_img3.png" alt="">
            <h1>FAMILY SHOP</h1>
            <p>패밀리샵은 모나미와 함께 협력하는<br>문구 소매 매장입니다.<br>주변 패밀리샵을 찾아보세요.</p>
            <li class="bn2_btn">
                <span>FIND SHOP</span>
            </li>
        </div>
    </div>
</div>

<?}else{?>

<style>
    #subBg{height: 300px;}
    #subBg .sbtImg{height: 300px;text-align: center;position: relative;}
    #subBg .sbtImg .title{
        width: 400px;color:#fff;   
        left: 50%;top: 50%;transform: translate(-50%,-50%);position: absolute;padding-top: 30px;
    }
    #subBg .sbtImg .title h2{font-size: 3em;color: #fff;}
    #subBg .sbtImg .title h2:after{content: "";display: block;width: 40px;height: 4px;background-color: #c40f39;margin:10px auto 15px auto;}
    .subTopBg_01{width: 100%;background:url(<? echo G5_THEME_IMG_URL ?>/sub1_img1.jpg) no-repeat;}

    #subBg .sbtImg{background-position: center;background-size: cover}
    
    .subTopBg_02{background:url(<? echo G5_THEME_IMG_URL ?>/sub2_img1.jpg) no-repeat;}
    .subTopBg_03{background:url(<? echo G5_THEME_IMG_URL ?>/sub3_img1.jpg) no-repeat;}
    .subTopBg_04{background:url(<? echo G5_THEME_IMG_URL ?>/sub4_img1.jpg) no-repeat;}
    .subTopBg_05{background:url(<? echo G5_THEME_IMG_URL ?>/sub5_img1.jpg) no-repeat;}   

</style>

<div id="subBg">
    <div id="page_title" class="sbtImg">
        <div class="title">
            <h2 class="loc1D"><!-- 1차메뉴 --></h2>
            <div class="text"></div>
        </div>
    </div>
</div>


<script>
    // window.onload = function(){};
    window.onload = function(){
        var menuDep = $("#subBg .loc1D").html();
        console.log("현재위치 :"+menuDep);

        if(menuDep  == "모나미소개"){
            $("#subBg .text").text("언제 어디서나 모나미는 당신 곁에 있습니다.")
        }else if(menuDep  == "모나미제품"){
            $("#subBg .text").text("모나미는 당신의 행복한 기록과 늘 함께 합니다.")
        }else if(menuDep  == "모나미박물관"){
            $("#subBg .text").text("알아두면 유용한 문구 정보를 소개합니다.")
        }else if(menuDep  == "고객지원"){
            $("#subBg .text").text("모나미는 언제나 소중한 의견에 귀 기울이겠습니다.")
        }else if(menuDep  == "NEWS&VIDEO"){
            $("#subBg .text").text("모나미는 늘 밝고 새로운 미래를 그려나갑니다.")
        }
    };
    
</script>
<?}?>







<!-- 콘텐츠 시작 { -->
<div id="wrapper">

   
    <div id="container">
      <?php if (!defined("_INDEX_")) { ?>
    
        <div>
            <span class="locationBar" title="현재위치">
            <span> <em class="fa fa-home" aria-hidden="true"></em> HOME 
            <i class="fa fa-angle-right" aria-hidden="true"></i> </span> 
            <span class="loc1D"><!-- 1차메뉴 --></span>
            <i class="fa fa-angle-right"></i> 
            <span class="loc2D"><!-- 2차메뉴 --></span>
        </span>
        </div>

         <h2 id="container_title" style="text-align: center;font-size: 2em;">
            
            <?php echo get_head_title($g5['title']); ?><br>

        </h2>
        <div class="subTitle">
            <? 
            $subTitle = get_head_title($g5['title']); //타이틀변수
            if( $subTitle == "모나미소개"){
            ?>
                <!-- <img src="<? echo G5_THEME_IMG_URL ?>/pc01.jpg"> -->
            <?
            }else if($subTitle  == "CEO메세지"){
                echo "글로벌기업 오시는길";
                echo "<img src='";
                echo G5_THEME_IMG_URL;
                echo "/pc01.jpg'>";
            }
            ?>
        </div>
        <?php } ?>
            