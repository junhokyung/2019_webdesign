<?php

include_once('./_common.php');


	$co_id = "testPage";

	//상단 메뉴바의 몇번째 1차메뉴에 속해 있는지 지정해 주세요.
	$menuNum = "1";

	//상단 메뉴바의 1차메뉴중 몇번째 2차메뉴에 속해 있는지 지정해 주세요.
	$menuNum2 = "5";
	
	//본 페이지의 제목을 입력해 주시기 바랍니다.
	$g5['title'] = "비젼";


include_once(G5_THEME_PATH.'/head.php');
?>
<script>
$(document).ready(function(){
	$('#snb > li:nth-child(<?php echo $menuNum; ?>)').addClass("co_id<?php echo $co_id; ?> active");
	$('#snb > li:nth-child(<?php echo $menuNum; ?>) > ul > li:nth-child(<?php echo $menuNum2; ?>)').addClass("snb2d_co_id<?php echo $co_id; ?>  active");
	});
</script>

<div>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magni corporis quibusdam, vero voluptate. Dolor recusandae ea, officiis, illum consequatur totam sunt alias non esse nulla aliquid doloribus sit fugit aspernatur laudantium ab quidem. Dolore tempore sequi magnam facere nemo fugit tempora recusandae ab rerum! Eos sit ullam ipsum sapiente neque magnam doloremque praesentium reiciendis, dolor architecto porro tempora perferendis fugit vero rerum totam odit, nam qui dolorem, iste quae non iusto. Suscipit asperiores iure pariatur rem fugit totam aliquid est eaque, minus ipsum culpa quod minima omnis cum quia sint voluptas exercitationem modi, sit dolor maiores dicta! Veniam, eligendi, placeat.</div>



<?php
include_once(G5_THEME_PATH.'/tail.php');
?>